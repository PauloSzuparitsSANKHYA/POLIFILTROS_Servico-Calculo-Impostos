<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>

<!DOCTYPE html>
<html>
<head>
    <title>Calcular Imposto / Valor Unitario</title>
    <link rel="stylesheet" type="text/css" href="${BASE_FOLDER}/css/calcula_imposto.css">
    <snk:load/>
    <script type="text/javascript" src="${BASE_FOLDER}/jx.js"></script>
</head>
<body>

<div class="ci-root">

    <!-- Filtros -->
    <div class="ci-filter-bar">
        <div class="ci-filter-group">
            <label class="ci-label">Nro Unico da Nota</label>
            <input id="inp-nunota" class="ci-input" type="number" placeholder="NUNOTA" style="width:140px" />
        </div>
        <div class="ci-filter-group ci-filter-search">
            <label class="ci-label">Produto</label>
            <input id="inp-busca" class="ci-input" type="text"
                   placeholder="Filtrar por referencia, descricao ou codigo..."
                   oninput="buscarProdutosComFiltro()" />
        </div>
    </div>

    <!-- Info bar -->
    <div class="ci-info-bar">
        <span id="lbl-count" class="ci-count">0 produto(s)</span>
        <span class="ci-hint">Clique em um produto para ver os alternativos e faixas de preco</span>
        <div style="flex:1"></div>
        <span id="lbl-loading" class="ci-loading" style="display:none">Buscando...</span>
    </div>

    <!-- Tabela de produtos -->
    <div class="ci-table-wrap">
        <table class="ci-table">
            <thead>
                <tr>
                    <th class="ci-th-cod">Codigo</th>
                    <th class="ci-th-ref">Referencia</th>
                    <th>Descricao</th>
                    <th class="ci-th-vol">Unidade</th>
                    <th class="ci-th-entrega">Prox. Entrega</th>
                </tr>
            </thead>
            <tbody id="tbody-produtos"></tbody>
        </table>
        <div id="btn-mais-wrap" class="ci-load-more" style="display:none">
            <button onclick="carregarMais()">Carregar mais</button>
        </div>
    </div>

    <!-- Overlay de alternativos + carrinho -->
    <div id="overlay-alt" class="ci-overlay" onclick="fecharAlternativos()">
        <div class="ci-alt-popup" onclick="event.stopPropagation()">

            <!-- Header -->
            <div class="ci-alt-header">
                <div class="ci-alt-header-info">
                    <span class="ci-alt-title">Produtos Alternativos</span>
                    <span id="alt-produto-nome" class="ci-alt-subtitle"></span>
                </div>
                <button class="ci-popup-close" onclick="fecharAlternativos()">&#x2715;</button>
            </div>

            <!-- Body: tabela de alternativos + carrinho -->
            <div class="ci-alt-body">

                <!-- Tabela -->
                <div class="ci-alt-table-section">
                    <div id="alt-loading" class="ci-alt-status" style="display:none">
                        <span class="ci-loading">Buscando produtos alternativos...</span>
                    </div>
                    <div id="alt-empty" class="ci-alt-status" style="display:none">
                        <span class="ci-alt-empty-msg">Nenhum produto alternativo encontrado.</span>
                    </div>
                    <div id="alt-table-wrap" class="ci-alt-table-wrap" style="display:none">
                        <table class="ci-alt-table" id="tbl-alt">
                            <thead>
                                <tr>
                                    <th class="ci-alt-th-tp">Tp</th>
                                    <th class="ci-alt-th-cod">Cod.</th>
                                    <th class="ci-alt-th-ref">Referencia</th>
                                    <th class="ci-alt-th-prod">Produto</th>
                                    <th class="ci-alt-th-marca">Marca</th>
                                    <th class="ci-alt-th-com">Comerc.</th>
                                    <th class="ci-alt-th-est">Estoque</th>
                                    <th class="ci-alt-th-est">Reservado</th>
                                    <th class="ci-alt-th-est">C. Pendente</th>
                                    <th class="ci-alt-th-entrega">Prox. Entrega</th>
                                    <th class="ci-alt-th-vlrcot">Últ. Cotação</th>
                                    <th class="ci-alt-th-vlrvda">Últ. Venda</th>
                                    <th class="ci-alt-th-faixa">Faixa 1</th>
                                    <th class="ci-alt-th-faixa">Faixa 2</th>
                                    <th class="ci-alt-th-faixa">Faixa 3</th>
                                    <th class="ci-alt-th-faixa">Faixa 4</th>
                                    <th class="ci-alt-th-faixa">Faixa 5</th>
                                    <th class="ci-alt-th-desc">Desc%</th>
                                    <th class="ci-alt-th-add"></th>
                                </tr>
                            </thead>
                            <tbody id="tbody-alt"></tbody>
                        </table>
                    </div>
                    <div id="btn-mais-alt-wrap" class="ci-load-more" style="display:none; margin:8px 0;">
                        <button id="btn-mais-alt" onclick="carregarMaisAlternativos()">Carregar mais alternativos</button>
                    </div>
                </div>

                <!-- Carrinho (visivel quando ha itens) -->
                <div id="cart-section" class="ci-cart-section" style="display:none">
                    <div class="ci-cart-header">
                        <span class="ci-cart-title">&#x1F6D2; Carrinho</span>
                        <span id="cart-count" class="ci-cart-count">0 item(ns)</span>
                        <div style="flex:1"></div>
                        <span class="ci-cart-total-label">Total:</span>
                        <span id="cart-total" class="ci-cart-total-val">R$ 0,00</span>
                    </div>
                    <div class="ci-cart-table-wrap">
                        <table class="ci-cart-table">
                            <thead>
                                <tr>
                                    <th class="ci-cart-th-cod">Cód.</th>
                                    <th class="ci-cart-th-prod">Produto</th>
                                    <th class="ci-cart-th-vlr">Vlr. Unitário</th>
                                    <th class="ci-cart-th-qtd">Qtd.</th>
                                    <th class="ci-cart-th-sub">Subtotal</th>
                                    <th class="ci-cart-th-del"></th>
                                </tr>
                            </thead>
                            <tbody id="tbody-cart"></tbody>
                        </table>
                    </div>
                    <div class="ci-cart-footer">
                        <button id="btn-finalizar" class="ci-btn-finalizar" onclick="finalizarCompra()">
                            Inserir na Nota
                        </button>
                    </div>
                </div>

            </div><!-- /ci-alt-body -->
        </div>
    </div>

</div>

<script type="text/javascript">
    var CARRINHO       = []; // [{codProd, descrProd, vlrUnit, qtd, codProdOrigem}]
    var CODPROD_ORIGEM = null;
    var PRODS_ALT      = [];
    var TEM_MAIS_ALT   = false;

    // Paginacao da lista principal (server-side)
    var OFFSET_MAIN   = 0;
    var TEM_MAIS_MAIN = false;
    var FILTRO_MAIN   = '';
    var DEBOUNCE_TIM  = null;

    /* -- Extrai NUNOTA da URL do navegador (hash do Sankhya) -- */
    function extrairNuNotaDaURL() {
        try {
            var hash = '';
            try { hash = window.top.location.hash;    } catch (e) {}
            if (!hash) { try { hash = window.parent.location.hash; } catch (e) {} }
            if (!hash) hash = window.location.hash;
            if (!hash) return null;
            var partes = hash.replace(/^#/, '').split('/');
            if (partes.length < 3) return null;
            var base64Json = partes[2].split('&')[0].split('?')[0];
            var obj = JSON.parse(atob(base64Json));
            return obj.NUNOTA ? String(obj.NUNOTA) : null;
        } catch (e) { return null; }
    }

    /* -- Init -- */
    window.onload = function() {
        var nuNotaDetectada = extrairNuNotaDaURL();
        if (nuNotaDetectada) document.getElementById('inp-nunota').value = nuNotaDetectada;

        // Delegacao de cliques na tabela de produtos
        document.getElementById('tbody-produtos').addEventListener('click', function(e) {
            var tr = e.target;
            while (tr && tr.tagName !== 'TR') tr = tr.parentNode;
            if (!tr || !tr.classList.contains('ci-row')) return;
            var prev = document.querySelector('#tbody-produtos .ci-row-sel');
            if (prev) prev.classList.remove('ci-row-sel');
            tr.classList.add('ci-row-sel');
            buscarAlternativos(tr.getAttribute('data-codprod'), tr.getAttribute('data-descr'));
        });

        // Delegacao de eventos do carrinho
        document.getElementById('tbody-cart').addEventListener('change', function(e) {
            var row = e.target.parentNode.parentNode;
            if (row && row.hasAttribute('data-codprod')) {
                atualizarLinhaPorRow(row);
                recalcularTotal();
            }
        });

        // Carga inicial de produtos
        buscarProdutosServico(false);
    };

    /* -- Lista de produtos (server-side) -- */
    function buscarProdutosServico(append) {
        document.getElementById('lbl-loading').style.display  = 'inline';
        document.getElementById('btn-mais-wrap').style.display = 'none';

        JX.chamarServico('servico-calcula-imposto@CalculaImpostoSP.buscarProdutos',
            { request: { offset: OFFSET_MAIN, limit: 20, filtro: FILTRO_MAIN || null } })
        .then(function(data) {
            document.getElementById('lbl-loading').style.display = 'none';
            var prods = data.responseBody && data.responseBody.body && data.responseBody.body.produtos
                        ? data.responseBody.body.produtos : [];
            TEM_MAIS_MAIN = data.responseBody && data.responseBody.body
                            ? (data.responseBody.body.temMais || false) : false;

            var tbody = document.getElementById('tbody-produtos');
            if (!append) tbody.innerHTML = '';
            for (var i = 0; i < prods.length; i++) tbody.appendChild(criarLinhaProduto(prods[i]));
            OFFSET_MAIN += prods.length;

            var total = document.querySelectorAll('#tbody-produtos .ci-row').length;
            document.getElementById('lbl-count').textContent = total + ' produto(s)';

            var btnMais = document.getElementById('btn-mais-wrap');
            if (TEM_MAIS_MAIN) {
                btnMais.style.display = '';
                btnMais.querySelector('button').textContent = 'Carregar mais';
            } else {
                btnMais.style.display = 'none';
            }
        })
        .catch(function(err) {
            document.getElementById('lbl-loading').style.display = 'none';
            console.error('[CI] Erro ao buscar produtos:', JSON.stringify(err));
        });
    }

    function buscarProdutosComFiltro() {
        clearTimeout(DEBOUNCE_TIM);
        DEBOUNCE_TIM = setTimeout(function() {
            FILTRO_MAIN = (document.getElementById('inp-busca').value || '').trim();
            OFFSET_MAIN = 0;
            buscarProdutosServico(false);
        }, 400);
    }

    function carregarMais() { buscarProdutosServico(true); }

    function criarLinhaProduto(p) {
        var tr = document.createElement('tr');
        tr.className = 'ci-row';
        tr.setAttribute('data-codprod', String(p.codProd));
        tr.setAttribute('data-descr',   p.descrProd  || '');
        tr.setAttribute('data-ref',     p.referencia || '');
        tr.setAttribute('data-vol',     p.codVol     || '');
        tr.innerHTML =
            '<td class="ci-td-cod">'     + esc(String(p.codProd))   + '</td>' +
            '<td class="ci-td-ref">'     + esc(p.referencia || '')  + '</td>' +
            '<td>'                        + esc(p.descrProd  || '')  + '</td>' +
            '<td class="ci-td-vol">'     + esc(p.codVol     || '')  + '</td>' +
            '<td class="ci-td-entrega">' + (p.dtProxEntrega || '-') + '</td>';
        return tr;
    }

    /* -- Buscar alternativos -- */
    function buscarAlternativos(codProd, descrProd) {
        var nunota = document.getElementById('inp-nunota').value;
        if (!nunota) { alert('Informe o Nro Unico da Nota antes de consultar.'); return; }

        CODPROD_ORIGEM = codProd;
        PRODS_ALT      = [];
        TEM_MAIS_ALT   = false;

        document.getElementById('alt-produto-nome').textContent        = '#' + codProd + ' — ' + descrProd;
        document.getElementById('alt-loading').style.display           = 'block';
        document.getElementById('alt-empty').style.display             = 'none';
        document.getElementById('alt-table-wrap').style.display        = 'none';
        document.getElementById('btn-mais-alt-wrap').style.display     = 'none';
        document.getElementById('tbody-alt').innerHTML                 = '';
        document.getElementById('overlay-alt').style.display           = 'flex';
        document.getElementById('lbl-loading').style.display           = 'inline';

        JX.chamarServico('servico-calcula-imposto@CalculaImpostoSP.buscarAlternativos',
            { request: { nuNota: Number(nunota), codProd: Number(codProd), offset: 0, limit: 10 } })
        .then(function(data) {
            document.getElementById('lbl-loading').style.display = 'none';
            document.getElementById('alt-loading').style.display = 'none';
            console.log('[CI] response completo:', JSON.stringify(data));
            var prods = data.responseBody && data.responseBody.body && data.responseBody.body.produtos
                        ? data.responseBody.body.produtos : [];
            TEM_MAIS_ALT = data.responseBody && data.responseBody.body ? (data.responseBody.body.temMais || false) : false;
            PRODS_ALT    = prods;
            console.log('[CI] prods extraídos:', prods.length, 'temMais:', TEM_MAIS_ALT);
            renderizarAlternativos(PRODS_ALT);
            document.getElementById('btn-mais-alt-wrap').style.display = TEM_MAIS_ALT ? '' : 'none';
        })
        .catch(function(err) {
            document.getElementById('lbl-loading').style.display = 'none';
            document.getElementById('alt-loading').style.display = 'none';
            console.log('[CI] ERRO:', JSON.stringify(err));
            fecharAlternativos();
            alert('Erro ao buscar alternativos: ' + (err && err.statusMessage ? err.statusMessage : 'Erro desconhecido'));
        });
    }

    /* -- Carregar mais alternativos -- */
    function carregarMaisAlternativos() {
        var nunota  = document.getElementById('inp-nunota').value;
        var codProd = CODPROD_ORIGEM;
        var btn     = document.getElementById('btn-mais-alt');
        btn.disabled    = true;
        btn.textContent = 'Carregando...';

        JX.chamarServico('servico-calcula-imposto@CalculaImpostoSP.buscarAlternativos',
            { request: { nuNota: Number(nunota), codProd: Number(codProd), offset: PRODS_ALT.length, limit: 10 } })
        .then(function(data) {
            var prods    = (data.responseBody && data.responseBody.body && data.responseBody.body.produtos)
                           ? data.responseBody.body.produtos : [];
            TEM_MAIS_ALT = data.responseBody && data.responseBody.body ? (data.responseBody.body.temMais || false) : false;
            PRODS_ALT    = PRODS_ALT.concat(prods);
            renderizarAlternativos(PRODS_ALT);
            btn.disabled    = false;
            btn.textContent = 'Carregar mais alternativos';
            document.getElementById('btn-mais-alt-wrap').style.display = TEM_MAIS_ALT ? '' : 'none';
        })
        .catch(function(err) {
            btn.disabled    = false;
            btn.textContent = 'Carregar mais alternativos';
            alert('Erro ao carregar mais: ' + (err && err.statusMessage ? err.statusMessage : 'Erro desconhecido'));
        });
    }

    /* -- Renderizar tabela de alternativos -- */
    function primeiraFaixa(p) {
        var fs = [p.faixa1, p.faixa2, p.faixa3, p.faixa4, p.faixa5];
        for (var i = 0; i < fs.length; i++) { if (fs[i] && Number(fs[i]) > 0) return Number(fs[i]); }
        return 0;
    }

    function renderizarAlternativos(prods) {
        if (prods && prods.length > 0) {
            prods.sort(function(a, b) {
                var comA = a.comercializa === 'S' ? 0 : 1;
                var comB = b.comercializa === 'S' ? 0 : 1;
                if (comA !== comB) return comA - comB;
                var f1A = (a.faixa1 != null && Number(a.faixa1) > 0) ? Number(a.faixa1) : Infinity;
                var f1B = (b.faixa1 != null && Number(b.faixa1) > 0) ? Number(b.faixa1) : Infinity;
                return f1A - f1B;
            });
        }
        var tbody = document.getElementById('tbody-alt');
        tbody.innerHTML = '';
        if (!prods || prods.length === 0) {
            document.getElementById('alt-empty').style.display      = 'block';
            document.getElementById('alt-table-wrap').style.display = 'none';
            return;
        }
        for (var i = 0; i < prods.length; i++) {
            var p          = prods[i];
            var isOriginal = p.ordemHierarquia === 0;
            var vlrDef     = primeiraFaixa(p);
            var jaNoCarr   = estaNoCarrinho(p.codProd);
            var tr         = document.createElement('tr');
            tr.className   = isOriginal
                ? 'ci-alt-row ci-alt-row-original'
                : ((p.percDesc && Number(p.percDesc) > 0)
                    ? 'ci-alt-row ci-alt-row-alt ci-alt-row-discount'
                    : 'ci-alt-row ci-alt-row-alt');

            tr.innerHTML =
                '<td class="ci-alt-td-tp">' +
                    (isOriginal ? '<span class="ci-alt-badge ci-alt-badge-original">ORIG</span>'
                                : '<span class="ci-alt-badge ci-alt-badge-alt">ALT</span>') +
                '</td>' +
                '<td class="ci-alt-td-cod">'   + esc(p.codProd)        + '</td>' +
                '<td class="ci-alt-td-ref">'   + esc(p.referencia)     + '</td>' +
                '<td class="ci-alt-td-prod">'  + esc(p.descrProd)      + '</td>' +
                '<td class="ci-alt-td-marca">' + esc(p.marca || '')    + '</td>' +
                '<td class="ci-alt-td-com">'   + esc(p.comercializa)   + '</td>' +
                '<td class="ci-alt-td-num">'   + fmtQtd(p.qtdEstoque)    + '</td>' +
                '<td class="ci-alt-td-num">'   + fmtQtd(p.qtdReservado)  + '</td>' +
                '<td class="ci-alt-td-num">'     + fmtQtd(p.compraPendente)             + '</td>' +
                '<td class="ci-alt-td-entrega">' + (p.dtProxEntrega || '-')              + '</td>' +
                '<td class="ci-alt-td-vlrcot">' + fmtPreco(p.vlrUltimaCotacao)          + '</td>' +
                '<td class="ci-alt-td-vlrvda">' + fmtPreco(p.vlrUltimaVenda)            + '</td>' +
                '<td class="ci-alt-td-faixa">' + fmtPreco(p.faixa1)   + '</td>' +
                '<td class="ci-alt-td-faixa">' + fmtPreco(p.faixa2)   + '</td>' +
                '<td class="ci-alt-td-faixa">' + fmtPreco(p.faixa3)   + '</td>' +
                '<td class="ci-alt-td-faixa">' + fmtPreco(p.faixa4)   + '</td>' +
                '<td class="ci-alt-td-faixa">' + fmtPreco(p.faixa5)   + '</td>' +
                '<td class="ci-alt-td-desc">'  + fmtPerc(p.percDesc)  + '</td>' +
                '<td class="ci-alt-td-add">' +
                    '<button class="ci-btn-add' + (jaNoCarr ? ' ci-btn-add-on' : '') + '" ' +
                        'data-codprod="'        + esc(String(p.codProd)) + '" ' +
                        'data-descr="'          + esc(p.descrProd)       + '" ' +
                        'data-vlr="'            + vlrDef                 + '" ' +
                        'data-codprod-origem="' + esc(String(CODPROD_ORIGEM)) + '" ' +
                        'data-faixa1="'         + (p.faixa1 != null ? p.faixa1 : '') + '" ' +
                        'data-faixa2="'         + (p.faixa2 != null ? p.faixa2 : '') + '" ' +
                        'data-faixa3="'         + (p.faixa3 != null ? p.faixa3 : '') + '" ' +
                        'data-faixa4="'         + (p.faixa4 != null ? p.faixa4 : '') + '" ' +
                        'data-faixa5="'         + (p.faixa5 != null ? p.faixa5 : '') + '" ' +
                        'onclick="toggleCarrinho(this)">' +
                        (jaNoCarr ? '&#x2713;' : '+') +
                    '</button>' +
                '</td>';
            tbody.appendChild(tr);
        }
        document.getElementById('alt-table-wrap').style.display = 'block';
    }

    /* -- Fechar overlay -- */
    function fecharAlternativos() {
        document.getElementById('overlay-alt').style.display       = 'none';
        document.getElementById('btn-mais-alt-wrap').style.display = 'none';
        PRODS_ALT    = [];
        TEM_MAIS_ALT = false;
        var sel = document.querySelector('#tbody-produtos .ci-row-sel');
        if (sel) sel.classList.remove('ci-row-sel');
    }

    /* -- Carrinho -- */
    function estaNoCarrinho(codProd) {
        for (var i = 0; i < CARRINHO.length; i++) {
            if (String(CARRINHO[i].codProd) === String(codProd)) return true;
        }
        return false;
    }

    function toggleCarrinho(btn) {
        var codProd       = btn.getAttribute('data-codprod');
        var descrProd     = btn.getAttribute('data-descr');
        var vlrDef        = parseFloat(btn.getAttribute('data-vlr')) || 0;
        var codProdOrigem = btn.getAttribute('data-codprod-origem') || '';
        var faixa1 = btn.getAttribute('data-faixa1') !== '' ? parseFloat(btn.getAttribute('data-faixa1')) : null;
        var faixa2 = btn.getAttribute('data-faixa2') !== '' ? parseFloat(btn.getAttribute('data-faixa2')) : null;
        var faixa3 = btn.getAttribute('data-faixa3') !== '' ? parseFloat(btn.getAttribute('data-faixa3')) : null;
        var faixa4 = btn.getAttribute('data-faixa4') !== '' ? parseFloat(btn.getAttribute('data-faixa4')) : null;
        var faixa5 = btn.getAttribute('data-faixa5') !== '' ? parseFloat(btn.getAttribute('data-faixa5')) : null;

        if (estaNoCarrinho(codProd)) {
            CARRINHO = CARRINHO.filter(function(i) { return String(i.codProd) !== String(codProd); });
            btn.textContent = '+';
            btn.classList.remove('ci-btn-add-on');
            var rowCart = document.querySelector('#tbody-cart tr[data-codprod="' + codProd + '"]');
            if (rowCart) rowCart.remove();
            atualizarHeaderCarrinho();
        } else {
            CARRINHO.push({ codProd: codProd, descrProd: descrProd, vlrUnit: vlrDef, qtd: 1, codProdOrigem: codProdOrigem, faixa1: faixa1, faixa2: faixa2, faixa3: faixa3, faixa4: faixa4, faixa5: faixa5 });
            btn.textContent = '&#x2713;';
            btn.classList.add('ci-btn-add-on');
            adicionarLinhaCarrinho(codProd, descrProd, vlrDef, 1, codProdOrigem);
            atualizarHeaderCarrinho();
        }

        document.getElementById('cart-section').style.display = CARRINHO.length > 0 ? '' : 'none';
    }

    function adicionarLinhaCarrinho(codProd, descrProd, vlrUnit, qtd, codProdOrigem) {
        var tbody = document.getElementById('tbody-cart');
        var tr = document.createElement('tr');
        tr.setAttribute('data-codprod', codProd);
        tr.setAttribute('data-codprod-origem', codProdOrigem || '');
        tr.innerHTML =
            '<td class="ci-cart-td-cod">'  + esc(codProd)   + '</td>' +
            '<td class="ci-cart-td-prod">' + esc(descrProd) + '</td>' +
            '<td class="ci-cart-td-vlr"><input type="number" class="ci-cart-input ci-cart-input-vlr" ' +
                'value="' + vlrUnit.toFixed(2) + '" step="0.01" min="0" /></td>' +
            '<td class="ci-cart-td-qtd"><input type="number" class="ci-cart-input ci-cart-input-qtd" ' +
                'value="' + qtd + '" step="1" min="1" /></td>' +
            '<td class="ci-cart-td-sub ci-cart-td-sub-val">R$ ' + fmt2(vlrUnit * qtd) + '</td>' +
            '<td class="ci-cart-td-del"><button class="ci-cart-btn-del" ' +
                'data-codprod="' + esc(codProd) + '" onclick="removerLinha(this)">&#x2715;</button></td>';
        tbody.appendChild(tr);
        recalcularTotal();
    }

    function removerLinha(btn) {
        var codProd = btn.getAttribute('data-codprod');
        CARRINHO = CARRINHO.filter(function(i) { return String(i.codProd) !== String(codProd); });
        btn.parentNode.parentNode.remove();
        var btnAlt = document.querySelector('#tbody-alt button.ci-btn-add[data-codprod="' + codProd + '"]');
        if (btnAlt) { btnAlt.textContent = '+'; btnAlt.classList.remove('ci-btn-add-on'); }
        atualizarHeaderCarrinho();
        if (CARRINHO.length === 0) document.getElementById('cart-section').style.display = 'none';
        recalcularTotal();
    }

    function atualizarLinhaPorRow(row) {
        var vlr = parseFloat(row.querySelector('.ci-cart-input-vlr').value) || 0;
        var qtd = Math.max(1, parseInt(row.querySelector('.ci-cart-input-qtd').value) || 1);
        row.querySelector('.ci-cart-input-qtd').value = qtd;
        var sub = row.querySelector('.ci-cart-td-sub-val');
        if (sub) sub.textContent = 'R$ ' + fmt2(vlr * qtd);
    }

    function recalcularTotal() {
        var total = 0;
        var rows = document.querySelectorAll('#tbody-cart tr[data-codprod]');
        for (var i = 0; i < rows.length; i++) {
            var vlr = parseFloat(rows[i].querySelector('.ci-cart-input-vlr').value) || 0;
            var qtd = parseFloat(rows[i].querySelector('.ci-cart-input-qtd').value) || 1;
            total += vlr * qtd;
        }
        document.getElementById('cart-total').textContent = 'R$ ' + fmt2(total);
    }

    function atualizarHeaderCarrinho() {
        document.getElementById('cart-count').textContent = CARRINHO.length + ' item(ns)';
        recalcularTotal();
    }

    /* -- Finalizar (inserir na nota) -- */
    function finalizarCompra() {
        var nunota = document.getElementById('inp-nunota').value;
        if (!nunota) { alert('NUNOTA nao preenchido.'); return; }

        var itens = [];
        var rows = document.querySelectorAll('#tbody-cart tr[data-codprod]');
        for (var i = 0; i < rows.length; i++) {
            var row           = rows[i];
            var codProd       = row.getAttribute('data-codprod');
            var codProdOrigem = row.getAttribute('data-codprod-origem');
            var vlrUnit       = parseFloat(row.querySelector('.ci-cart-input-vlr').value) || 0;
            var qtd           = Math.max(1, parseFloat(row.querySelector('.ci-cart-input-qtd').value) || 1);
            var cartItem      = CARRINHO.filter(function(c) { return String(c.codProd) === String(codProd); })[0] || {};
            itens.push({ codProd: Number(codProd), vlrUnit: vlrUnit, qtd: qtd, codProdOrigem: codProdOrigem ? Number(codProdOrigem) : null, faixa1: cartItem.faixa1 || null, faixa2: cartItem.faixa2 || null, faixa3: cartItem.faixa3 || null, faixa4: cartItem.faixa4 || null, faixa5: cartItem.faixa5 || null });
        }

        if (itens.length === 0) { alert('Carrinho vazio.'); return; }

        var btn = document.getElementById('btn-finalizar');
        btn.disabled    = true;
        btn.textContent = 'Inserindo...';

        JX.chamarServico('servico-calcula-imposto@CalculaImpostoSP.incluirItens',
            { request: { nuNota: Number(nunota), itens: itens } })
        .then(function(data) {
            btn.disabled    = false;
            btn.textContent = 'Inserir na Nota';
            if (String(data.status) === '0' || (data.tsError && data.tsError.tsErrorLevel === 'ERROR')) {
                alert(data.statusMessage || 'Erro ao inserir itens na nota.');
                return;
            }
            var msg = data.responseBody && data.responseBody.body && data.responseBody.body.mensagem
                      ? data.responseBody.body.mensagem : 'Itens inseridos com sucesso!';
            var liberacoesPendentes = data.responseBody && data.responseBody.body && data.responseBody.body.liberacoesPendentes;
            CARRINHO = [];
            document.getElementById('tbody-cart').innerHTML = '';
            document.getElementById('cart-section').style.display = 'none';
            var btns = document.querySelectorAll('#tbody-alt button.ci-btn-add-on');
            for (var i = 0; i < btns.length; i++) {
                btns[i].textContent = '+';
                btns[i].classList.remove('ci-btn-add-on');
            }
            fecharAlternativos();
            if (liberacoesPendentes && liberacoesPendentes.length > 0) {
                alert(msg + '\n\nAtencao - Liberacoes pendentes na nota:\n' + liberacoesPendentes.join('\n'));
            } else {
                alert(msg);
            }
        })
        .catch(function(err) {
            btn.disabled    = false;
            btn.textContent = 'Inserir na Nota';
            alert('Erro ao inserir: ' + (err && err.statusMessage ? err.statusMessage : 'Erro desconhecido'));
        });
    }

    /* -- Utilitarios -- */
    function fmt2(n) {
        return Number(n).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    function fmtPreco(v) {
        if (v === null || v === undefined || Number(v) === 0) return '<span class="ci-alt-nd">—</span>';
        return 'R$ ' + fmt2(v);
    }
    function fmtPerc(v) {
        if (v === null || v === undefined || Number(v) === 0) return '<span class="ci-alt-nd">—</span>';
        return Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 2 }) + '%';
    }
    function fmtQtd(v) { return (v === null || v === undefined) ? '0' : fmt2(v); }
    function esc(v) {
        if (v === null || v === undefined) return '';
        return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
</script>

</body>
</html>
